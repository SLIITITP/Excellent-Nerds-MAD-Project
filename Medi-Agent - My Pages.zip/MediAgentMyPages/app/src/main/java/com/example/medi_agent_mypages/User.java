package com.example.medi_agent_mypages;

public class User {

    public String fullname, dob, email,password;

    public User(){};

    public User ( String fullname, String dob, String email,String password){

        this.fullname = fullname;
        this.dob = dob;
        this.email = email;
        this.password = password;
    }

}
